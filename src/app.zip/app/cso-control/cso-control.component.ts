import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cso-control',
  templateUrl: './cso-control.component.html',
  styleUrls: ['./cso-control.component.css']
})
export class CsoControlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
