import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-humanresource',
  templateUrl: './humanresource.component.html',
  styleUrls: ['./humanresource.component.css']
})
export class HumanresourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
