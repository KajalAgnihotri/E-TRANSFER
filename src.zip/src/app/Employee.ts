export class Employee{
    constructor(public employeeCode:string,public employeeName:string,
        public employeeEmailId:string,public location:string,public localHR:string,
        public localCSO:string,public oucode:string,public pacode:string,public psacode:string,
        public ccCode:string,public companyCode:string,public designation:string,
        public supervisor:string,public dateOfTransfer:string,public assetCode:string,
        public supervisorName:string,public supervisorEmailId:string)
{}}
