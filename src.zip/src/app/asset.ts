export class AssetsData{
    constructor(public assetid:string,public assetcode:string,
        public employeeCode:string,public companycode:string,
        public description:string,public quantity:string,
        public location:string,public capitalisationdate:string,
        public assetstatus:string,public assignedto:string ,public emailid:string){}
}
